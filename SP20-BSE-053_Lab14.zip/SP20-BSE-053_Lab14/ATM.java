import java.util.*;
import java.io.*;

public class ATM implements Serializable {
    private String name;
    private double balance = 900000;
    private String accountNo;



    Scanner scan = new Scanner(System.in);

    public ATM(String name, String accountNo) {
        super();
        this.name = name;
        this.accountNo = accountNo;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }


    @Override
    public String toString() {
        return  "\nATM_Account:" + "\nAccount Name: "+name+" \nAccountNumber='" + accountNo + "\nBalance=" + balance +"\n";
    }

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    public double getBalance() {
        return (double) balance;
    }

    public void setBalance(int balance) {
        this.balance += balance;
    }


    public void deposit() {

        System.out.println("\nDeposit Money:\nEnter Deposit Amount: ");
        int amount = scan.nextInt();
        balance += amount;
        System.out.println("Amount is successfully Deposited \nRemaining balance: " + balance);

    }

    public void  withdraw() {

        System.out.println("\nWithdraw Money:\nEnter Withdrawn Amount ");
        int amount = scan.nextInt();
        balance -= amount;
        System.out.println("Cash is withdrawn!! \nRemaining balance left: " + balance);

    }

    public void transfer(ATM To, ATM From) {

        System.out.println("\nTransfer Money:\nEnter Amount to transfer: ");
        int amount = scan.nextInt();
        To.setBalance((int) (balance + amount));
        From.setBalance((int) (balance - amount));
        System.out.println(amount + " RS Amount is transferred ");

    }

    public void  balance_inquiry() {
        double balance = getBalance();
        System.out.println("Remaining Balance left now: " + balance);
    }





    public static void write_File(ArrayList<ATM> record) {
        FileOutputStream bookStream;
        try {

            bookStream = new FileOutputStream("E:\\ATM.txt");
            ObjectOutputStream os = new ObjectOutputStream(bookStream);
            os.writeObject(record.toString());
            os.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static void read_File(ArrayList<ATM> record) {

        try {
            FileInputStream inputStream = new FileInputStream("E:\\ATM.txt");
            ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
            System.out.println(objectInputStream.readObject());

            objectInputStream.close();

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    
}
