import java.util.ArrayList;

public class Lab14_Runner {
       public static void main(String[] args) {
        ATM obj1 = new ATM("Anis", "1114455");
        ATM obj2 = new ATM("Jia", "363893");
        ATM obj3 = new ATM("Johny", "533238");
        ATM obj4= new ATM("Usama", "783777");
        ATM obj5 = new ATM("Peter", "5603334");
        ATM obj6 = new ATM("Sam", "537267");
        ATM obj7 = new ATM("Hania", "537353");
        ATM obj8 = new ATM("Hamza", "433837");
        ATM obj9 = new ATM("Zehra", "632378");
        ATM obj10 = new ATM("Emaan", "936373");



        ArrayList<ATM> user = new ArrayList<ATM>();


        user.add(obj1);
        user.add(obj2);
        user.add(obj3);
        user.add(obj4);
        user.add(obj5);
        user.add(obj6);
        user.add(obj7);
        user.add(obj8);
        user.add(obj9);
        user.add(obj10);


        ATM.write_File(user);



        obj2.deposit();
        obj6.balance_inquiry();
        obj5.withdraw();
        obj1.transfer(obj2, obj3);

        System.out.println(obj1.toString());
        System.out.println(obj2.toString());
        System.out.println(obj3.toString());
        System.out.println(obj4.toString());
        System.out.println(obj5.toString());
        System.out.println(obj6.toString());
        System.out.println(obj7.toString());
        System.out.println(obj8.toString());
        System.out.println(obj9.toString());
        System.out.println(obj10.toString());

}
}