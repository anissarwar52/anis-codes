package LAB9Ass;

public class runner {

	public static void main(String[] args) {
		     
            PhdStudent s1=new PhdStudent();
            GradStudent s2=new GradStudent();
            s1.takeXam();
            s2.takeXam();
        }
	}


