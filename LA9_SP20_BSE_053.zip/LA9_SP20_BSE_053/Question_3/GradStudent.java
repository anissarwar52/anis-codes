/**
 * 
 */
package LAB9Ass;

public class GradStudent extends Student{
	    
	    public void takeXam(){
	        System.out.println("Giving Exams.");
	    }
}

