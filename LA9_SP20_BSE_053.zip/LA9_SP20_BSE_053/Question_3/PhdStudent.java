package LAB9Ass;

public class PhdStudent extends Student{
    
    public void takeXam(){
        System.out.println("Giving Thesis");
        
    }
}


