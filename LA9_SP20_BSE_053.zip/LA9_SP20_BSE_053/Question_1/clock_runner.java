package LAB9Ass;

public class clock_runner {

	public static void main(String[] args) {
		  
	     ClockExtended t_obj=new ClockExtended("00","39","41");
	     ClockExtended t_obj1=new ClockExtended("13","24","45");  
	            t_obj.display();
	            t_obj1.display();
	        }

	}


