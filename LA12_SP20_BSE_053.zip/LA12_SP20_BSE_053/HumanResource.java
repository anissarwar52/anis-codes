package lab12;
import java.util.ArrayList;

public class HumanResource {
    private Association[] resources;

	public void add(Association res){
	    if (resources == null)
	        resources = new Association[1];
	    else
	        extend();

	        resources[resources.length-1] = res;
	    }


	    public void delete(int pointer)
	    {
	        resources[pointer-1] = null;
	        Association[] associate = new Association[resources.length - 1];
	        int k = 0;
	        while (resources[k] != null) {
	        	associate[k] = resources[k];
	            k++;
	        }

	        for (int j = k; j < associate.length; j++)
	        {
	        	resources[j+1]= associate[j];
	        }
	        associate = resources;

	    }
	    public String toString(){
	        String ga = "";

	        for(int i = 0; i<resources.length; i++){
	            ga += resources[i]+"\n";
	        }

	        return ga;
	    }

	    private void extend()
	    {
	        Association[] Anis = new Association[resources.length + 1];
	        for (int i = 0; i < resources.length; i++)
	        {
	        	if(resources.length>0)
	        	Anis[i] = resources[i];
	        }
	        resources = Anis;
	    }
}