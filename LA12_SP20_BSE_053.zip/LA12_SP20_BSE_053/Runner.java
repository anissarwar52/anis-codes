package lab12;

import java.util.ArrayList;

public class Runner {
	public static void main(String[] args) {
	{
		//Asking for Teacher info.
	    Teacher t1 = new Teacher("Mukhtar Azeem", "0011");
	    Teacher t2 = new Teacher("Ahsan", "0012");
	    Teacher t3 = new Teacher("Ali", "0013");

		//Asking for Student info.
	    Student s1 = new Student("Anis", "051");
	    Student s2 = new Student("Sadiq", "052");
	    Student s3 = new Student("Farzand", "053");
	    
		
	   
	    ArrayList<Association> obj1 = new ArrayList<Association>();
	    //Adding Teacher Data
	    obj1.add (t1) ;
	    obj1.add (t2) ;
	    obj1.add (t3) ;
	    
	    //Adding Student Data
	    obj1.add (s1) ;
	    obj1.add (s2) ;
	    obj1.add (s3) ;
	    
	    obj1.remove(2);
	    
	    //Printing Data
	    System.out.println(obj1);

	}
	       
	         /*  HumanResource HR = new HumanResource();
	        HR.add(s1);
	        HR.add(s2);
	        HR.add(s3);
	       
	        HR.add(t1);
	        HR.add(t2);
	       HR.add(t3);
	        HR.delete(3);
	        System.out.println(HR);*/


	}
	}
