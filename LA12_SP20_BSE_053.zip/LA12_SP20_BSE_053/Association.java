package lab12;

public interface Association {
	void associate();
}
